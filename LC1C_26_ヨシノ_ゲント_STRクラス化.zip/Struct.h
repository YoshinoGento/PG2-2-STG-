﻿#pragma once

struct Vector2 {
	float x;
	float y;
};

enum Scene {
	TITLE,
	GAME,
	GAMEOVER,
	CLEAR,
};